INSERT INTO EMPLOYEE_TBL (NAME, DATE_OF_BIRTH, AVATAR_URL, JOB_ROLE, GENDER, AGE, EMAIL) VALUES
 ('Alice Johnson', '1990-05-21', 'https://example.com/avatar/alice', 'Software Engineer', 'Female', 33, 'ajohnson@example.com'),
 ('Bob Smith', '1985-08-10', 'https://example.com/avatar/bob', 'DevOps Engineer', 'Male', 38, 'bsmith@example.com'),
 ('Charlie Davis', '1992-03-15', 'https://example.com/avatar/charlie', 'QA Engineer', 'Non-binary', 32, 'cdavis@example.com'),
 ('Diana Evans', '1988-11-05', 'https://example.com/avatar/diana', 'Project Manager', 'Female', 35, 'devans@example.com'),
 ('Evan Green', '1993-07-25', 'https://example.com/avatar/evan', 'UX Designer', 'Male', 31, 'egreen@example.com');

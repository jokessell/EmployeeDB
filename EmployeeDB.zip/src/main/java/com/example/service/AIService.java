package com.example.service;

import com.example.dto.GenerateDataRequestDto;
import com.example.dto.OpenAIRequest;
import com.example.dto.OpenAIResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AIService {

    @Value("${openai.api.key}")
    private String openAiApiKey;

    private final WebClient webClient;

    public List<String> generateTestData(GenerateDataRequestDto requestDto) {
        try {
            // Build the OpenAIRequest object
            OpenAIRequest openAIRequest = buildOpenAIRequest(requestDto);

            // Make the API call and map the response to OpenAIResponse
            OpenAIResponse openAIResponse = webClient.post()
                    .uri("https://api.openai.com/v1/completions")
                    .header("Authorization", "Bearer " + openAiApiKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(openAIRequest)
                    .retrieve()
                    // Use clientResponse.statusCode().isError() for error handling
                    .onStatus(HttpStatusCode::isError, this::handleError)
                    .bodyToMono(OpenAIResponse.class)
                    .block();  // Blocking to retrieve the result

            // Extract generated data
            return extractGeneratedData(openAIResponse);

        } catch (WebClientResponseException e) {
            System.err.println("Error from OpenAI: " + e.getResponseBodyAsString());
            throw new RuntimeException("Failed to generate data from OpenAI API");
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            throw new RuntimeException("Unexpected error occurred while generating data");
        }
    }

    // Helper method to create OpenAIRequest
    private OpenAIRequest buildOpenAIRequest(GenerateDataRequestDto requestDto) {
        String prompt = String.format("Generate %d records of %s with %d properties each.",
                requestDto.getRecordCount(), requestDto.getDataType(), requestDto.getPropertyCount());
        return new OpenAIRequest("gpt-3.5-turbo", prompt, 1000);
    }

    // Helper method to extract generated data
    private List<String> extractGeneratedData(OpenAIResponse openAIResponse) {
        if (openAIResponse == null || openAIResponse.getChoices() == null) {
            throw new RuntimeException("Invalid response from OpenAI API");
        }

        return openAIResponse.getChoices().stream()
                .map(OpenAIResponse.Choice::getText)
                .collect(Collectors.toList());
    }

    // Helper method to handle errors
    private Mono<Throwable> handleError(ClientResponse clientResponse) {
        return clientResponse.bodyToMono(String.class)
                .flatMap(errorBody -> {
                    System.err.println("Error from OpenAI API: " + errorBody);
                    return Mono.error(new RuntimeException("Error from OpenAI API: " + errorBody));
                });
    }
}

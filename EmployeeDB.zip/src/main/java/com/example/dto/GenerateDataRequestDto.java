package com.example.dto;

import lombok.Data;

@Data
public class GenerateDataRequestDto {
    private String dataType;
    private int recordCount;
    private int propertyCount;
}

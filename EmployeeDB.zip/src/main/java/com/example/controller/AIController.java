package com.example.controller;

import com.example.dto.GenerateDataRequestDto;
import com.example.service.AIService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/ai")
@RequiredArgsConstructor
public class AIController {

    private final AIService aiService;

    @PostMapping("/generate-data")
    public List<String> generateData(@RequestBody GenerateDataRequestDto requestDto) {
        return aiService.generateTestData(requestDto);
    }
}
